"""Generate original procedural HDR skies and repeatable microsurface textures.
No photographs, generated-image model, or pre-rendered water are used.
Clouds use a single-scattering volume approximation; not a meteorological model.
"""
from pathlib import Path
import numpy as np
from scipy.ndimage import map_coordinates, gaussian_filter, zoom
from PIL import Image
import json, time
OUT=Path(__file__).resolve().parents[1]/'public/assets';OUT.mkdir(exist_ok=True)
rng=np.random.default_rng(53107)
noise=rng.random((64,64,64),dtype=np.float32)

def n3(p,scale=1):
    shape=p.shape[:-1];q=(p*scale).reshape(-1,3).T
    return map_coordinates(noise,[q[2],q[1],q[0]],order=1,mode='grid-wrap',prefilter=False).reshape(shape)
def smooth(a,b,x):
    t=np.clip((x-a)/(b-a),0,1);return t*t*(3-2*t)
def density(p,coverage):
    h=(p[...,1]-1600)/2350
    a=n3(p,.00040);b=n3(p,.00092);c=n3(p,.0021)
    weather=n3(p,.000075)
    f=.60*a+.28*b+.12*c
    base=.50+coverage+.18*np.clip(h,0,1)-.15*(weather-.5)
    d=np.clip((f-base)*8,0,1)
    return d*smooth(0,.10,h)*(1-smooth(.72,1,h))

def sky(name,W=2048,H=1024):
    start=time.time()
    spec={
    'dawn':dict(sun=[-.72,.082,-.69],zenith=[.045,.10,.20],horizon=[.34,.25,.20],sunlight=[2.25,1.1,.48],coverage=.048,exposure=1.05),
    'blue':dict(sun=[-.4,.48,-.78],zenith=[.055,.17,.39],horizon=[.36,.52,.70],sunlight=[2.1,2.03,1.85],coverage=.075,exposure=1.0),
    'storm':dict(sun=[-.6,.20,-.77],zenith=[.058,.086,.12],horizon=[.28,.36,.42],sunlight=[.43,.49,.55],coverage=-.080,exposure=1.0)
    }[name]
    theta=(np.arange(H,dtype=np.float32)+.5)/H*np.pi
    phi=(np.arange(W,dtype=np.float32)+.5)/W*2*np.pi-np.pi
    sy=np.cos(theta)[:,None]*np.ones((1,W),np.float32)
    d=np.stack([np.sin(theta)[:,None]*np.cos(phi)[None,:],sy,np.sin(theta)[:,None]*np.sin(phi)[None,:]],axis=-1)
    sun=np.array(spec['sun'],np.float32);sun/=np.linalg.norm(sun)
    zen=np.array(spec['zenith'],np.float32);hor=np.array(spec['horizon'],np.float32)
    up=np.maximum(sy,0)
    grad=np.power(up,.45)[...,None]
    col=hor*(1-grad)+zen*grad
    mu=np.sum(d*sun,axis=-1)
    glow=np.exp(-(1-mu)*16)[...,None]
    col+=glow*np.array(spec['sunlight'])*.22
    # A long low-angle aerosol glow; the solar disk is evaluated at render time.
    if name=='dawn':
        warm=np.array([.55,.24,.075],np.float32)
        col+=np.exp(-up*9)[...,None]*np.maximum(mu,0)[...,None]**6*warm
    mask=sy>0.012
    dirs=d[mask];skybase=col[mask]
    t0=1600/dirs[:,1];t1=3950/dirs[:,1]
    # Limited far integration merges into atmospheric extinction at the horizon.
    t1=np.minimum(t1,170000);step=np.maximum(t1-t0,0)/28
    T=np.ones(len(dirs),np.float32);radiance=np.zeros_like(dirs)
    ambience=np.array(spec['horizon'],np.float32)*.56+np.array(spec['zenith'],np.float32)*.28
    direct=np.array(spec['sunlight'],np.float32)
    # Noise bands are sampled in world space. Lighting uses a short sun transmittance trace.
    for j in range(28):
        t=t0+(j+.5)*step;p=dirs*t[:,None]
        p[:,0]+=12000;p[:,2]-=4500
        rho=density(p,spec['coverage'])
        tau=rho*.00165*step;atten=np.exp(-tau)
        light_od=np.zeros(len(dirs),np.float32)
        for dist,ds in [(160,260),(550,550),(1300,1000),(2700,1800)]:
            light_od+=density(p+sun[None,:]*dist,spec['coverage'])*ds*.0015
        sunT=np.exp(-light_od)
        phase=.34+.48*np.exp(-(1-np.sum(dirs*sun,axis=-1))*9)
        # Powder/multiple-scattering closure deliberately bounded for energy stability.
        cloud_light=ambience[None,:]*(.64+.36*np.exp(-rho*2))[:,None]+direct[None,:]*(sunT*phase+.065)[:,None]
        radiance+=T[:,None]*(1-atten)[:,None]*cloud_light
        T*=atten
    result=skybase*T[:,None]+radiance
    haze=1-np.exp(-t0*.000011)
    haze=np.maximum(haze,1-smooth(.012,.085,dirs[:,1]))
    result=result*(1-haze[:,None]) + skybase*haze[:,None]
    col[mask]=result
    col[sy<0]=np.broadcast_to(hor*.24,col.shape)[sy<0]
    rgba=np.ones((H,W,4),np.float16);rgba[...,:3]=np.maximum(col,0)
    rgba[...,3][mask]=T
    ui=int(((np.arctan2(sun[2],sun[0])/(2*np.pi)+.5)%1)*W);vi=int(np.arccos(sun[1])/np.pi*H)
    print("sun transmittance",name,float(rgba[vi,ui,3]),flush=True)
    rgba.tofile(OUT/f'{name}.rgba16f')
    # Preview exposure uses the same ACES curve as the app.
    x=col*spec['exposure'];rgb=np.clip((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0,1)**(1/2.2)
    Image.fromarray((rgb*255).astype('uint8')).save(OUT/f'{name}-sky.jpg',quality=91)
    print(name,round(time.time()-start,2),'s',flush=True)

for name in ['dawn','blue','storm']:sky(name)
# A multi-octave periodic scalar field, not a pre-rendered normal map.
N=512
base=np.zeros((N,N),np.float32)
for res,amp in [(8,.27),(16,.23),(32,.19),(64,.14),(128,.10),(256,.07)]:
    small=rng.random((res,res),dtype=np.float32)
    yy,xx=np.mgrid[:N,:N].astype(np.float32);coords=[yy/N*res,xx/N*res]
    base+=amp*map_coordinates(small,coords,order=3,mode='grid-wrap',prefilter=True)
base=np.clip(base,0,1)
fine=rng.random((N,N),dtype=np.float32)
channels=np.stack([base,np.roll(base,137,0),np.roll(base,237,1),fine],axis=-1)
Image.fromarray((channels*255).astype('uint8'),'RGBA').save(OUT/'micro.png')
(OUT/'manifest.json').write_text(json.dumps({'skies':{'width':2048,'height':1024,'format':'RGBA16F little-endian','names':['dawn','blue','storm']},'origin':'Original procedural radiance fields and texture noise. No generated-image model or water image assets.'},indent=2))
