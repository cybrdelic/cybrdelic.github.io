from pathlib import Path
import re,gzip,base64,json,argparse
ROOT=Path(__file__).resolve().parents[1]
public=ROOT/'public'
modules=['math','fft','ocean','interaction','shaders','geometry','backend','app']
parts=[]
for module in modules:
 text=(public/'src'/f'{module}.js').read_text()
 text=re.sub(r'^import .*?;\s*$', '', text, flags=re.M)
 text=re.sub(r'\bexport\s+(?=(class|const|function|let|var)\b)','',text)
 parts.append('// --- '+module+'.js ---\n'+text)
code='\n'.join(parts)
assets={}
for name in ['dawn.rgba16f','blue.rgba16f','storm.rgba16f','micro.png']:
 data=(public/'assets'/name).read_bytes();compressed=gzip.compress(data,compresslevel=9)
 assets['assets/'+name]={'gzip':True,'data':base64.b64encode(compressed).decode()}
html=(public/'index.html').read_text()
vendor=public/'vendor/three.global.js'
if vendor.exists():html=html.replace('<script type="module" src="src/app.js"></script>', '<script>'+vendor.read_text()+'</script>\n<script type="module" src="src/app.js"></script>')
html=html.replace('<script type="module" src="src/app.js"></script>', '<script>window.__ASSETS__='+json.dumps(assets,separators=(',',':'))+';</script>\n<script type="module">\n'+code+'\n</script>')
parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(ROOT.parent/'CYBR-WATER.html'));args=parser.parse_args()
output=Path(args.output);output.parent.mkdir(parents=True,exist_ok=True);output.write_text(html)
print(str(output),output.stat().st_size)
