import test from 'node:test';
import assert from 'node:assert/strict';
import {FFT} from '../public/src/fft.js';
import {G,TAU,dispersion,groupVelocity,fresnelDielectric,mulberry32,V,perspective,lookAt,matmul} from '../public/src/math.js';
import {Ocean,PRESETS,SpectralCascade} from '../public/src/ocean.js';
import {RippleField,Buoy} from '../public/src/interaction.js';
import {oceanGeometry} from '../public/src/geometry.js';
const near=(actual,expected,epsilon=1e-9)=>assert.ok(Math.abs(actual-expected)<=epsilon,`${actual} != ${expected}; tolerance ${epsilon}`);
const finite=a=>assert.ok(a.every(Number.isFinite));

for(const n of [2,4,8,16,64,128])test(`FFT complex round-trip N=${n}`,()=>{
 const r=mulberry32(915),re=Float64Array.from({length:n},r),im=Float64Array.from({length:n},r),rr=re.slice(),ii=im.slice(),fft=new FFT(n);
 fft.transform(re,im,0,1,false);fft.transform(re,im);
 for(let i=0;i<n;i++){near(re[i],rr[i],2e-13);near(im[i],ii[i],2e-13);}
});
test('FFT agrees with independent direct DFT',()=>{
 const n=16,r=mulberry32(532),re=Float64Array.from({length:n},r),im=Float64Array.from({length:n},r),rr=re.slice(),ii=im.slice();new FFT(n).transform(re,im,0,1,false);
 for(let k=0;k<n;k++){let ar=0,ai=0;for(let j=0;j<n;j++){const a=-TAU*k*j/n,c=Math.cos(a),s=Math.sin(a);ar+=rr[j]*c-ii[j]*s;ai+=rr[j]*s+ii[j]*c;}near(re[k],ar,1e-12);near(im[k],ai,1e-12);}
});
test('2D FFT normalized impulse becomes constant 1/N²',()=>{
 const n=16,re=new Float64Array(n*n),im=new Float64Array(n*n);re[0]=1;new FFT(n).transform2D(re,im);for(const x of re)near(x,1/n/n,1e-15);for(const x of im)near(x,0,1e-15);
});
test('FFT rejects non-power-of-two sizes and malformed 2D buffers',()=>{
 assert.throws(()=>new FFT(6),RangeError);assert.throws(()=>new FFT(1),RangeError);assert.throws(()=>new FFT(4).transform2D(new Float32Array(12),new Float32Array(16)),RangeError);
});
test('Gravity-wave deep-water dispersion limit',()=>{for(const k of [.01,.1,1,10])near(dispersion(k,10000),Math.sqrt(G*k),1e-12);});
test('Gravity-wave shallow-water dispersion limit',()=>{const k=1e-5,h=3;near(dispersion(k,h)/k,Math.sqrt(G*h),1e-8);});
test('Group velocity agrees with finite-difference dω/dk',()=>{for(const depth of [.5,3,20,180])for(const k of [.01,.1,1,10]){const e=k*1e-5,numeric=(dispersion(k+e,depth)-dispersion(k-e,depth))/(2*e);near(groupVelocity(k,depth),numeric,1e-7);}});
test('Dielectric Fresnel: normal incidence, grazing, total internal reflection',()=>{
 near(fresnelDielectric(1),((1-1.333)/(1+1.333))**2,1e-14);near(fresnelDielectric(0),1);near(fresnelDielectric(.3,1.333,1),1);
 for(let i=0;i<=100;i++){const f=fresnelDielectric(i/100);assert.ok(f>=0&&f<=1);}
});
test('Camera view matrix maps eye to origin',()=>{const eye=[4,6,8],m=lookAt(eye,[0,0,0]);for(let row=0;row<3;row++)near(m[row]*eye[0]+m[4+row]*eye[1]+m[8+row]*eye[2]+m[12+row],0,1e-6);});
test('Ocean mesh indices are valid and finite at the centre/horizon',()=>{const g=oceanGeometry(40,64,12500);finite(g.vertices);assert.ok(g.indices.every(i=>i<g.vertices.length/3));assert.equal(g.indices.length/3,40*64*2);});
test('Seeded spectral realization is reproducible',()=>{const a=new Ocean('dawn',32),b=new Ocean('dawn',32);a.step(17.4,.02);b.step(17.4,.02);for(let i=0;i<3;i++)assert.deepEqual(a.cascades[i].displacement,b.cascades[i].displacement);});
test('Ocean Hs normalization is correct in expectation',()=>{for(const key of Object.keys(PRESETS)){const o=new Ocean(key,64),variance=o.cascades.reduce((sum,c)=>sum+c.expectedVariance,0);near(4*Math.sqrt(variance),PRESETS[key].hs,1e-12);}});
test('Cascade spectral supports do not overlap',()=>{
 const o=new Ocean('blue',128),bands=[[16,769],[2,16],[.25,2]];
 for(let j=0;j<3;j++){const c=o.cascades[j];for(let i=0;i<c.h0r.length;i++)if(c.h0r[i]||c.h0i[i]){const wavelength=TAU/Math.hypot(c.kx[i],c.kz[i]);assert.ok(wavelength>=bands[j][0]-1e-5&&wavelength<bands[j][1]+1e-5);}}
});
test('All presets remain finite; zero DC height; near-real inverse FFT',()=>{
 for(const key of Object.keys(PRESETS)){const o=new Ocean(key,128);for(const t of [0,.033,7,42,100,1000]){o.step(t,.033);const d=o.diagnostics();assert.ok(Math.abs(d.meanHeight)<2e-6);assert.ok(d.maxImaginaryResidual<2e-5);for(const c of o.cascades){finite(c.displacement);finite(c.derivativeX);finite(c.derivativeZ);assert.ok(c.foam.every(x=>x>=0&&x<=1));}}}
});
test('Phase evolution is continuous for a small time increment',()=>{const o=new Ocean('dawn',64);o.step(5,0);const before=o.cascades[0].hr.slice();o.step(5+1e-4,1e-4);let max=0;for(let i=0;i<before.length;i++)max=Math.max(max,Math.abs(before[i]-o.cascades[0].hr[i]));assert.ok(max<.005,`height change ${max}`);});
test('Periodic bilinear cascade sampling wraps exactly',()=>{const o=new Ocean('dawn',64);o.step(7,.02);for(const c of o.cascades)for(const [x,z]of[[0,0],[4.125,-7.6],[-12.8,18.2]]){const a=c.sample(x,z),b=c.sample(x+c.length,z-c.length);for(let i=0;i<4;i++)near(a[i],b[i],1e-12);}});
test('Foam follows exponential decay when births and drift are disabled',()=>{const c=new Ocean('dawn',32).cascades[0];c.foam.fill(.5);c.evolve(3,.2,{foamThreshold:-100,foamGain:0,drift:[0,0]});for(const f of c.foam)near(f,.5*Math.exp(-.2/5.5),5e-8);});
test('Local impulse is neutral in total height volume',()=>{const r=new RippleField(64,32,1.5);r.impulse(2.3,-3.7,.5,1.4);assert.ok(Math.abs(r.mass())<1e-6);});
test('Closed periodic shallow-water patch preserves zero mass for 20 s',()=>{const r=new RippleField(64,32,1.5);r.impulse(0,0,.3,1.6);for(let i=0;i<600;i++)r.step(1/30,{sponge:false});assert.ok(Math.abs(r.mass())<2e-5);finite(r.data);});
test('Shallow-water energy remains bounded without a sponge',()=>{const r=new RippleField(64,32,1.5);r.impulse(0,0,.1,1.8);const initial=r.energy();let lo=initial,hi=initial;for(let i=0;i<400;i++){r.step(1/30,{sponge:false});lo=Math.min(lo,r.energy());hi=Math.max(hi,r.energy());}assert.ok(lo>initial*.85&&hi<initial*1.15,JSON.stringify({initial,lo,hi}));});
test('Sponge intentionally dissipates outgoing wave energy',()=>{const r=new RippleField(64,32,1.5);r.impulse(0,0,.3,1.8);const initial=r.energy();for(let i=0;i<750;i++)r.step(1/30);assert.ok(r.energy()<initial*.30);});
test('CFL bound subdivides a large requested time step',()=>{const r=new RippleField(32,16,1.5);assert.ok(r.maxDt<r.dx/Math.sqrt(2*G*r.depth));r.impulse(0,0,.2,1.2);r.step(1);finite(r.height);assert.ok(r.energy()<10);});
test('Exact submerged sphere cap: empty, hemisphere, full',()=>{const r=.9;near(Buoy.submergedVolume(r,-1),0);near(Buoy.submergedVolume(r,r),2/3*Math.PI*r**3);near(Buoy.submergedVolume(r,9),4/3*Math.PI*r**3);});
test('Buoy settles close to Archimedean equilibrium',()=>{const b=new Buoy();for(let i=0;i<9000;i++)b.step(1/120,0);assert.ok(Math.abs(1025*b.wetVolume-b.mass)/b.mass<.012);assert.ok(Math.abs(b.vy)<.04);assert.ok(Number.isFinite(b.y));});
