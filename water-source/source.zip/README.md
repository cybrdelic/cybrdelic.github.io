# CYBR WATER — spectral ocean laboratory

A runnable ocean rendering project with a genuine Three.js adapter, a deterministic CPU spectral solver, and an independently usable WebGL2 backend. This is an original implementation; it does not contain Water Pro code or assets.

## Run

Open `standalone.html` in a desktop browser with WebGL2. The generated standalone file bundles Three.js, the application, and original procedural HDR environments. No API keys are needed. The header tells you which renderer is actually active.

For the modular development version, from the project root:

```
npm install
mkdir -p public/vendor
cp node_modules/three/build/three.module.js public/vendor/
cp node_modules/three/build/three.core.js public/vendor/
npm start
```

Open `http://localhost:8000`. The Three.js version is pinned to 0.180.0. Without a local dependency it attempts the pinned CDN and then explicitly falls back to its dependency-free WebGL2 renderer. Add `?offline=1` to force that fallback. Add `?quality=high` to increase the radial mesh tessellation.

## Controls

1 / 2 / 3 change the sea state; drag rotates the view; wheel changes distance; Space pauses; B toggles the diagnostic buoy; H hides the interface; N cycles normal/compression views; D opens diagnostics. Double-click the water to excite a local wave packet. The film button toggles camera choreography. The record button captures a 24-second WebM from the actual canvas.

## Model boundaries

The main ocean is a **linear, finite-depth gravity-wave model**, not volumetric Navier–Stokes. Three disjoint wavelength bands use JONSWAP-shaped random spectra, directional spreading, Hermitian phase evolution, and inverse FFTs. An artistic horizontal displacement sharpens crests. Foam uses compression-driven birth, semi-Lagrangian drift, and decay; spray is ballistic decoration. Neither represents a mass-conserving breaking-water phase.

The interaction patch is a separate linear shallow-water height/velocity solver with CFL substeps and an absorbing boundary. It is superimposed on the ocean, not conservatively or bidirectionally coupled. Its reference depth is 1.5 m independently of the ocean preset depth. The buoy is an ideal sphere constrained horizontally, using exact spherical-cap volume, Archimedean force, gravity, and quadratic vertical drag. It is not a general rigid-body hydrodynamics solver.

Optics use exact dielectric Fresnel, Snell refraction, Beer–Lambert attenuation, a GGX sun lobe, procedural sand, and reflected HDR sky. The diagnostic sphere has analytic reflection/refraction intersections. Arbitrary objects, shorelines, underwater cameras, breaking surf, caustic transport, and water-volume conservation are **not implemented**. Crest scattering, sky illumination, and foam appearance use bounded artistic approximations. The fixed sky assets do not simulate weather evolution. A nice-looking movie is not proof of physical validation or of superiority to another renderer.

## Reproducibility and verification

Run `npm test`. The suite checks the complex FFT against an independent DFT, normalization, dispersion limits, group velocity, dielectric reflection, finite fields, zero DC height, seeded reproducibility, phase continuity, periodic sampling, foam decay, neutral interaction impulses, closed-domain height conservation, bounded interaction energy, absorbing boundaries, CFL subdivision, exact sphere-cap volume, and buoy equilibrium. These are implementation checks, not experimental validation of the entire rendered ocean.

The nominal significant wave heights are 2.7, 3.4 and 6.8 m. The measured single-realization RMS height varies with the seed and time; the UI reports its estimate instead of claiming it always equals the nominal value. Zero mean spectral height is not the same as proving physical water-volume conservation after choppy displacement.

The CPU solver performs nine 128×128 inverse transforms per update. GPU rendering uses 128,000 water triangles by default and 286,720 at high quality. Performance is hardware-dependent; recordings may be captured offline at a fixed simulation timestep and are not evidence of real-time frame rate.

## Build original assets

```
python -m pip install numpy scipy pillow
python tools/make_assets.py
npx --yes esbuild@0.25.9 node_modules/three/build/three.module.js --bundle --format=iife --global-name=THREE --minify --outfile=public/vendor/three.global.js
python tools/build.py --output public/standalone.html
```

All environment radiance and microsurface fields are generated procedurally from seeds. No image-generation model or stock footage is involved.

## License

Original project code: MIT. Three.js retains its own MIT license, included with the vendored dependency. The numerical models and physical equations are general methods, not proprietary Water Pro implementation details.
